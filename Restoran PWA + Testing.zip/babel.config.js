module.exports = {
  presets: [
    '@babel/preset-env', // For compiling modern JavaScript
  ],
};
